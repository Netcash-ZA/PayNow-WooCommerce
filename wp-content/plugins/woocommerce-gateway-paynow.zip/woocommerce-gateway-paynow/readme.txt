=== WooCommerce Sage Pay Now Gateway ===

A payment gateway for Sage Pay Now. A Sage Pay Now merchant account and service key are required for this gateway to function.

== Important Note ==

An SSL certificate is recommended for additional safety and security for your customers.